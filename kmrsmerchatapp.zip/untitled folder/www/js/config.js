var krms_config ={				
    'ApiUrl':"https://foodsquire.com/merchantapp/api",	    
	'DialogDefaultTitle' : "FoodSquire Merchant",
	'pushNotificationSenderid': "491618252405",
	'APIHasKey': "59af8bfae4fa5f1e78d1c1103d3e1b0f"
};
